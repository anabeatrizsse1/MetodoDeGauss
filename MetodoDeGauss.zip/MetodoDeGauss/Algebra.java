// Aluna: Ana Beatriz Silva e Silva
import java.util.Scanner;

public class Algebra {

    
    public static void main(String[] args) {
        int i, j, k, n;
        float matrizfin;
        String literales = "";
        char variavel;
        System.out.print(" ----Calculadora---- \n ----METODO De GAUSS----\n");
        
        try (Scanner in = new Scanner(System.in)) {
            System.out.print("Qual o numero de equacoes? ");
              n = Integer.parseInt(in.nextLine());
            float[][] matriz = new float[n][n+1];
            for(i=0; i<n; i++)
            {
                System.out.print("Insira suas variavel" + (i+1) + ": ");
                do {
                    variavel = in.nextLine().toLowerCase().charAt(0);
                } while(!Character.isLetter(variavel) || literales.contains(String.valueOf(variavel)));
                literales = literales + variavel;
            }
            for(i=0; i<n; i++)
            {
                for(j=0; j<n; j++)
                {
                    System.out.print("Insira o coeficiente dessa variavel '" + literales.charAt(j) + "' dessa equacao " + (i+1) + ": ");
                    matriz[i][j] = Float.parseFloat(in.nextLine());
                }
                System.out.print("insira a constante" + (i+1) + ": ");
                matriz[i][n] = Float.parseFloat(in.nextLine());
            }
            System.out.println();
            for(i=0; i<n; i++)
            {
                if(matriz[i][i]==0.0)
                {
                    System.err.println("erro! nao eh possivel dividir por zero");
                    return;
                }
                for(k=0; k<n; k++)
                    if(k!=i)
                    {
                        matrizfin = matriz[k][i] / matriz[i][i];
                        for(j=0; j<=n; j++)
                            matriz[k][j] -= matrizfin * matriz[i][j];
                    }
            }
            System.out.println("A solucao desse sistema eh: \n");
            for(i=0; i<n; i++)
            {
                matrizfin = matriz[i][n] / matriz[i][i];
                System.out.println(literales.charAt(i) + " = " + matrizfin);
            }
        } catch (NumberFormatException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println();
    
}


}
 
